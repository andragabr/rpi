import traceback
from subprocess import *
import json
import pprint
import os
import string
import time
import requests


class mifare(object):
    data_read = None
    status = None
    uid = None
    MIFAREReader = None
    TVD = None
    lcd = None

    # This is the default key for authentication
    mifare_key = [0xCC, 0x5A, 0x85, 0xDA, 0x4E, 0x76]
    MODULE_PATH = os.path.abspath(os.path.dirname(__file__))
    OPENFLEET_CARD_SERVICE = "http://localhost:8080"

    class MFError(Exception):
        pass

    class MFReadError(MFError):
        pass

    class MFWriteError(MFError):
        pass

    class MFAuthError(MFError):
        pass

    class MFInvalidCard(MFError):
        pass

    class MFInsufficientFunds(MFError):
        pass

    class MFAlreadyValidated(MFError):
        pass

    def __init__(self, mifare_reader, tvd, lcd=None):
        self.MIFAREReader = mifare_reader
        self.TVD = tvd

        if lcd is not None:
            self.lcd = lcd

        (self.status, self.uid) = self.MIFAREReader.MFRC522_Anticoll()

        uid_str = format(self.uid[0], 'x').zfill(2)
        uid_str += format(self.uid[1], 'x').zfill(2)
        uid_str += format(self.uid[2], 'x').zfill(2)
        uid_str += format(self.uid[3], 'x').zfill(2)
        self.uuid = int(uid_str, 16)

        if self.status == self.MIFAREReader.MI_OK:
            # Print UID
            print "uid_str:",  uid_str, "uuid:", self.uuid

            # Select the scanned tag
            self.MIFAREReader.MFRC522_SelectTag(self.uid)
        else:
            print "mifare __init__: Reader error"
            self.MIFAREReader.MFRC522_StopCrypto1()
            return None

    def int2base(self, x, base):
        digs = string.digits + string.letters
        if x < 0: sign = -1
        elif x == 0: return digs[0]
        else: sign = 1
        x *= sign
        digits = []
        while x:
            digits.append(digs[x % base])
            x /= base
        if sign < 0:
            digits.append('-')
            digits.reverse()
        return ''.join(digits)

    def card_tool(self, card_data, json_command):
        if '/openfleetcardtool/' not in self.MODULE_PATH:
            self.MODULE_PATH += '/openfleetcardtool/'

        java_classpath = self.MODULE_PATH + ":"
        java_classpath += self.MODULE_PATH + "/OpenFleetCard.jar:"
        java_classpath += self.MODULE_PATH + "/lib/gson-2.6.2.jar"
        card_tool_cmd = 'java -cp "' + java_classpath + '" com.opendevlabs.openfleet.cardtool.OpenFleetCard '
        card_data = "'" + card_data + "'"
        json_command = "'" + json_command + "'"
        card_tool_cmd += card_data + ' ' + json_command
        print "card_tool_cmd:", card_tool_cmd
        p = Popen(card_tool_cmd, shell=True, stdout=PIPE, stderr=STDOUT)
        resp = p.stdout.readlines()[0]
        return resp

    def card_tool_request(self, card_data, json_command):
        req_data = {
            "card_data": card_data,
            "command_data": json_command
        }
        print json.dumps(req_data, indent=2)
        r = requests.post(self.OPENFLEET_CARD_SERVICE, data=json.dumps(req_data, indent=2), timeout=2)
        resp = r.json()
        return resp

    def read(self):
        # Dump the data
        self.data_read = self.MIFAREReader.MFRC522_ReadCardFull(self.mifare_key, self.uid)
        # print "Data read:\n", self.data_read

        if self.data_read is None:
            raise self.MFReadError

    def write(self, data_write):
        # print "data write:", data_write

        for i in range(0, 64, 4):
            # Authenticate
            status = self.MIFAREReader.MFRC522_Auth(self.MIFAREReader.PICC_AUTHENT1A, i, self.mifare_key, self.uid)

            # Check if authenticated
            if status == self.MIFAREReader.MI_OK:

                for j in range(i, i + 3):
                    if j == 0:
                        continue

                    block = data_write[j*32:j*32+32]

                    blocks = []

                    for x in range(0, 32, 2):
                        val = block[x:x+2]
                        blocks.append(int(val, 16))

                    if i % 4 == 0:
                        if blocks == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]:
                            # Exit prematurely if next sector is 0
                            return

                    (status, message) = self.MIFAREReader.MFRC522_Write(j, blocks)

                    if status is False:
                        raise self.MFWriteError

            else:
                raise self.MFAuthError

    def validate(self, second=False, consult=False, price=250):
        try:
            self.read()

            tool_cmd = {
                "command": "validateTicket",
                "params": {
                    "ticketPrice": price,
                    "routeID": self.TVD['BusLine'],
                    "graphicID": self.TVD['GraphicId'],
                    "direction": self.TVD['Direction'],
                    "extraUrban": False,
                    "busControllerID": self.TVD['BusControllerId'],
                    "maxTravelDurationMinutes": 60,
                }
            }

            if second:
                tool_cmd['command'] = "validateAnotherTicket"

            if consult:
                tool_cmd['command'] = "decodeCard"

            time_start_card_tool = time.time()
            resp_card_tool = json.loads(self.card_tool(self.data_read, json.dumps(tool_cmd)))
            # resp_card_tool = json.loads(self.card_tool_request(self.data_read, tool_cmd))
            time_end_card_tool = time.time()
            print "card tool time:", time_end_card_tool-time_start_card_tool
            tool_status = resp_card_tool['status']

            print "raspunsul de la card tool -> ", tool_cmd['command'], ": ", resp_card_tool
            print "datele trimise pt cardtool:", self.data_read

            resp_card_tool['card']['uid'] = self.uid
            resp_card_tool['card']['uuid'] = self.uuid

            # pp = pprint.PrettyPrinter(indent=4)
            # print "card resp:"
            # pp.pprint(resp_card_tool)

            if tool_status == 0:
                if not consult:
                    self.write(str(resp_card_tool['blocks'].decode('utf8')))
                    if second:
                        print "validate: validare suplimentara cu succes"
                    else:
                        print "validate: validare primara cu succes"
                else:
                    print "validate: consultare cu succes"
                return resp_card_tool
            else:
                print "validate: error:", resp_card_tool['message']
                raise self.MFInvalidCard

        except Exception as e:
            traceback.print_exc()
            print e
            raise e

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.MIFAREReader.MFRC522_StopCrypto1()

    def __del__(self):
        self.MIFAREReader.MFRC522_StopCrypto1()
