import serial
from time import sleep
import time
from datetime import datetime, timedelta
import threading
from subprocess import *
import requests
import urllib3
from urllib3.exceptions import InsecureRequestWarning
import json
import os

import RPi.GPIO as GPIO
from Adafruit_CharLCD import Adafruit_CharLCD
import MFRC522

from mifare import mifare


urllib3.disable_warnings(InsecureRequestWarning)


class Validator(object):
    ip_cmd = "ip -4 addr show eth0 | grep inet | awk '{print $2}' | cut -d/ -f1"
    ping_cmd = "ping -c1 fleet-dev.opendevlabs.com"

    RS = 40
    E = 33
    DB = [38, 37, 36, 35]
    lcd = None

    BACKFEED = 32

    BUTTON1 = 31
    BUTTON2 = 29

    BUZZER = 13

    LED_GREEN = 15
    LED_RED = 16
    LED_OFF = 0  # For programming sake

    FILENAME_TVD = '/home/pi/tvd.json'
    FILENAME_TRANSACTIONS = '/home/pi/transactions.json'

    lcd = None
    MIFAREReader = None
    prn = None
    button_pressed = False

    cards_sync_done = False

    have_net = False

    device_id = None

    TVD = {
        'BusId': 'N/A',
        'BusLine': 'N/A',
        'BusControllerId': '1234567890',
        'Direction': False,
        'GraphicId': '01',
        'Validate': True,
        'PollInterval': 5,
    }

    API = {
        'api_host': 'https://fleet-dev.opendevlabs.com',
        'api_transaction': '/ticketing/transactions.json',
        'api_inspectors': '/ticketing/inspectors/',
        'api_black_list': '',
        'api_tvd_lock': 'http://192.168.1.201:8080/',
    }

    transactions = []

    def __init__(self):
        GPIO.setmode(GPIO.BOARD)
        GPIO.setwarnings(False)

        mac = self.get_mac("eth0")
        self.device_id = int(mac.replace(':', ''), 16)

        self.lcd = Adafruit_CharLCD(self.RS, self.E, self.DB, GPIO)
        self.lcd.begin(16, 2)
        self.lcd.clear()
        self.lcd.message("ASTEAPTA".center(16))
        self.lcd.message("\n")
        self.lcd.message("RETEA".center(16))

        self.MIFAREReader = MFRC522.MFRC522(reset_pin=22)

        self.reading_card = threading.Event()

        self.read_lock = threading.Lock()
        self.display_lock = threading.Lock()

        self.t_checkIP = threading.Thread(target=self.check_ip)
        self.t_checkIP.start()

        self.t_checkNET = threading.Thread(target=self.check_NET)
        self.t_checkNET.start()

        self.t_getTVD = threading.Thread(target=self.get_TVD)
        self.t_getTVD.start()

        self.t_transactionSync = threading.Thread(target=self.transaction_sync)
        self.t_transactionSync.start()

        self.t_heartbeat = threading.Thread(target=self.heartbeat)
        self.t_heartbeat.start()

        self.init_printer()

        self.load_config()
        self.load_transactions()

        self.setup()

        self.t_UpdateLCDTime = threading.Thread(target=self.print_time_thread)
        self.t_UpdateLCDTime.start()

    def load_config(self):
        try:
            with open(self.FILENAME_TVD, 'r') as tvd_data:
                self.TVD = json.loads(tvd_data.read())
        except Exception as e:
            print "load_config EXC:", e

    def load_transactions(self):
        try:
            with open(self.FILENAME_TRANSACTIONS, 'r') as transaction_data:
                self.transactions = json.loads(transaction_data.read())
        except Exception as e:
            print "load_transactions EXC:", e

    def get_mac(self, intf):
        mac = None
        for line in os.popen("/sbin/ifconfig " + intf):
            if line.find('Ether') > -1:
                mac = line.split()[4]
                break
        return mac

    def get_version(self):
        try:
            p = Popen('cd /home/pi/busticket && git describe', shell=True, stdout=PIPE)
            output = p.communicate()[0]
        except Exception as e:
            output = 'N/A'
        finally:
            return output

    def get_ip_address(self, intf):
        ip_address = None
        try:
            for line in os.popen("/sbin/ifconfig " + intf):
                if line.find('inet addr') > -1:
                    ip_address = line.split()[1]
                    ip_address = ip_address.split(':')[1]
                    break
        except Exception as e:
            print e
        return ip_address

    def init_printer(self):
        try:
            self.prn = serial.Serial(
                port='/dev/ttyUSB0',
                baudrate=9600,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
                timeout=1
            )
        except Exception as e:
            print "Nu am gasit PRN la USB0", str(e)
            try:
                self.prn = serial.Serial(
                    port='/dev/ttyUSB1',
                    baudrate=9600,
                    parity=serial.PARITY_NONE,
                    stopbits=serial.STOPBITS_ONE,
                    bytesize=serial.EIGHTBITS,
                    timeout=1
                )
            except Exception as e:
                print "Nu am gasit PRN la USB1", str(e)

    def setup(self):
        print "setup: start"

        GPIO.setup(self.BACKFEED, GPIO.OUT)
        GPIO.output(self.BACKFEED, GPIO.HIGH)

        GPIO.setup(self.LED_GREEN, GPIO.OUT)
        GPIO.output(self.LED_GREEN, GPIO.LOW)
        GPIO.setup(self.LED_RED, GPIO.OUT)
        GPIO.output(self.LED_RED, GPIO.LOW)

        GPIO.setup(self.BUTTON1, GPIO.IN, pull_up_down=GPIO.PUD_UP)
        GPIO.add_event_detect(self.BUTTON1, GPIO.FALLING, callback=self.button1_pressed_handler, bouncetime=3000)

        GPIO.setup(self.BUTTON2, GPIO.IN, pull_up_down=GPIO.PUD_UP)
        GPIO.add_event_detect(self.BUTTON2, GPIO.FALLING, callback=self.button2_pressed_handler, bouncetime=3000)

        GPIO.setup(self.BUZZER, GPIO.OUT)

        self.buzzer_beep()

        self.print_ip()
        self.print_version()
        self.print_time()
        print "setup: end"

    def save_transaction_data(self):
        # Save transaction data to file
        try:
            with open(self.FILENAME_TRANSACTIONS, 'w') as transactions:
                data = json.dumps(self.transactions)
                # print "save_transactions_data:", data
                transactions.write(data)
        except Exception as e:
            print "transaction_sync EXC:", e
            # traceback.print_exc()

    def transaction_sync(self):
        while True:
            if len(self.transactions):
                try:
                    api_url = self.API['api_host'] + self.API['api_transaction']
                    # FIXME remove this in the future to enable cert validation
                    http = urllib3.PoolManager(cert_reqs='CERT_NONE')
                    data_sync = {
                        'device_uuid': self.TVD['BusControllerId'],
                        'validator_uuid': self.device_id,
                        'transactions': self.transactions,
                        'tickets': [],
                    }
                    data_sync = json.dumps(data_sync)
                    # print "data_sync:", data_sync
                    r = http.urlopen('POST',
                                     api_url,
                                     headers={'Content-Type': 'application/json'},
                                     body=data_sync,
                                     timeout=7)
                    resp = r.data
                    resp = json.loads(resp)
                    # print "transaction_sync:", resp

                    if resp['success']:
                        # Successful transmission, empty the list
                        self.transactions = []

                    self.save_transaction_data()

                except Exception as e:
                    print "data_sync: Nu pot comunica cu serverul:", e
                    # traceback.print_exc()
                    self.save_transaction_data()
            time.sleep(10)

    def controller_send_card_id(self, card_id):
        print "send card_id:", card_id

        try:
            api_url = self.API['api_tvd_lock']
            card_data = {
                'card_id': card_id,
            }
            r = requests.post(api_url, data=card_data)
            resp = r.json()
            print "controller_send_card_id:", resp

            if resp['success']:
                print "controller_send_card_id: Transmis card_id catre OBCA"
                return resp

        except Exception as e:
            print "controller_send_card_id: Nu pot comunica cu OBCA:", e

    def register_mifare_transaction(self, val_resp):
        try:
            # add transaction to self.transactions
            transaction = {
                'timestamp': int(time.time()),
                'route': self.TVD['BusLine'],
                'schedule': self.TVD['GraphicId'],
                'license_plate': self.TVD['BusId'],
                'title_type': 2,
                'subscription_id': val_resp['card']['wallet']['validatedSubscriptionID'],
                'card_serial_number': val_resp['card']['uuid'],
                'card_user_type': val_resp['card']['header']['userType'],
                'transaction_type': 1,
                'value': val_resp['lastExpense'] / 100.00,
            }

            # Is this a subscription validation or a card validation?
            if 'walletValidation' in val_resp and val_resp['walletValidation']:
                transaction['transaction_type'] = 0

            self.transactions.append(transaction)
        except Exception as e:
            print e

    def validate_card(self, second=False, consult=False):
        print "validate_card: start"
        card = None

        start_time = time.time()

        if self.read_lock.acquire(False):
            try:
                self.display_lock.acquire(True)

                self.lcd.clear()
                self.lcd.message("MENTINETI CARDUL")

                # citeste card si ia banii de pe el
                try:
                    card = mifare(self.MIFAREReader, self.TVD, self.lcd)
                    if card is not None:
                        val_resp = card.validate(second=second, consult=consult)
                        self.lcd.clear()

                        # For all employee cards
                        try:
                            user_type = val_resp['card']['header']['userType']
                            if user_type == 100:
                                    self.lcd.message('CARD ANGAJAT'.center(16))
                                    self.lcd.message('\n' + 'DATE PRELUATE'.center(16))
                                    self.register_mifare_transaction(val_resp)
                                    sleep(1)
                                    self.lcd.clear()
                        except Exception as e:
                            print e

                        if consult:
                            # For inspectors, lock/unlock the validators
                            try:
                                if user_type == 100:
                                    resp = self.controller_send_card_id(val_resp['card']['uuid'])
                                    if resp['success']:
                                        if 'isTicketInspector' in resp and resp['isTicketInspector']:
                                            self.TVD['Validate'] = False
                            except Exception as e:
                                print e

                            val_portofel = val_resp['card']['wallet']['credit'] / 100.0
                            self.lcd.message('PORTOFEL'.center(16))
                            self.lcd.message('\n' + str(str(val_portofel) + ' RON').center(16))
                            sleep(2)
                            if len(val_resp['card']['subscriptions']):
                                for sub in val_resp['card']['subscriptions']:
                                    self.lcd.clear()
                                    if sub['routeID'] != '':
                                        if sub['secondRouteID'] != '':
                                            line1_str = "ABON. "
                                            line1_str += sub['routeID'] + ' & ' + sub['secondRouteID']
                                        else:
                                            line1_str = "ABONAMENT "
                                            line1_str += sub['routeID']
                                    else:
                                        line1_str = "ABON. TOATE"
                                    line1_str = line1_str.center(16)
                                    expire_date = datetime.fromtimestamp(sub['validityStartTimestamp'])
                                    time_delta = timedelta(minutes=sub['validityDuration'])
                                    expire_date += time_delta
                                    line2_str = 'EXP: ' + expire_date.strftime('%d/%m/%y')
                                    line2_str = '\n' + line2_str.center(16)
                                    self.lcd.message(line1_str)
                                    self.lcd.message(line2_str)
                                    sleep(2)
                        else:
                            self.turn_led(self.LED_GREEN)
                            if user_type != 100:
                                # Was the card already validated for the current trip?
                                if 'alreadyValidated' in val_resp and val_resp['alreadyValidated']:
                                    self.lcd.message('CARD'.center(16))
                                    self.lcd.message('\n' + 'DEJA VALIDAT'.center(16))
                                else:
                                    self.lcd.message('CARD VALIDAT'.center(16))

                                    if second:
                                        self.lcd.message('\n' + 'SUPLIMENTAR'.center(16))
                                    else:
                                        val_detail_str = ''
                                        self.lcd.message('\n' + val_detail_str.center(16))

                                self.register_mifare_transaction(val_resp)

                        end_time = time.time()
                        print "validate_card: end, durata:", end_time - start_time, "s"
                    else:
                        raise Exception("mifare init failed")
                except Exception as e:
                    print e
                    self.turn_led(self.LED_RED)
                    self.lcd.clear()
                    self.lcd.message('CARD INVALID'.center(16))
                    sleep(1)
                    self.display_lock.release()
                    raise Exception(e)

                self.buzzer_beep()
                sleep(1)
                self.turn_led(self.LED_OFF)
                self.display_lock.release()
                self.print_time()
                sleep(2)
            except Exception as e:
                print "Eroare:", e
                # traceback.print_exc()
            finally:
                print "validate_card: finally"
                self.read_lock.release()
        else:
            print "door #card locked"

        if card is not None:
            del card

    def check_ip(self):
        while True:
            p = Popen(self.ip_cmd, shell=True, stdout=PIPE)
            output = p.communicate()[0]

            if '192.168.1' not in output:
                print "Reset eth0"
                c = Popen('ifdown eth0 ; ifup eth0', shell=True, stdout=PIPE)
                o = c.communicate()

            sleep(10)

    def check_NET(self):
        while True:
            p = Popen(self.ping_cmd, shell=True, stdout=PIPE)
            output = p.communicate()[0]

            if '1 received' in output:
                self.have_net = True
            else:
                self.have_net = False

            # print "have_net:", self.have_net

            sleep(30)

    def heartbeat(self):
        while True:
            try:
                api_url = "https://eta.opendevlabs.com/equipment/device/" + str(self.device_id) + "/heartbeat/"
                # FIXME remove this in the future to enable cert validation
                http = urllib3.PoolManager(cert_reqs='CERT_NONE')
                data = {
                    'device_id': self.device_id,
                    'uptime': 1000,
                    'sw_version': self.get_version(),
                    'ip_address': self.get_ip_address('tun0'),
                    'type': 'EqType.BusTicket',
                }

                r = http.urlopen('POST',
                                 api_url,
                                 headers={'Content-Type': 'application/json'},
                                 body=json.dumps(data),
                                 timeout=7)

            except Exception as e:
                print "heartbeat: Nu pot comunica cu serverul:", e
            sleep(60 * 5)

    def get_TVD(self):
        while True:
            try:
                # print "GET TVD"
                http = urllib3.PoolManager(cert_reqs='CERT_NONE')
                r = http.urlopen('GET', 'http://192.168.1.201:8080/')
                resp = r.data
                self.TVD = json.loads(resp)

                if self.TVD['BusLine'] == '':
                    self.TVD['BusLine'] = 'N/A'

                if self.TVD['BusId'] == '':
                    self.TVD['BusId'] = 'VLN/A'

                if 'GraphicId' not in resp:
                    self.TVD['GraphicId'] = 'N/A'

                if 'Direction' not in resp:
                    self.TVD['Direction'] = False

                if 'BusControllerId' not in resp:
                    self.TVD['BusControllerId'] = '0000000000'

                if not self.have_net:
                    set_time = 'date --set="' + self.TVD['DateTime'] + '"'
                    # print set_time
                    c = Popen(set_time, shell=True, stdout=PIPE)
                    c.communicate()

                # Save TVD Data to file
                try:
                    with open(self.FILENAME_TVD, 'w') as tvd_data:
                        data = json.dumps(self.TVD)
                        # print "save_tvd_data:", data
                        tvd_data.write(data)
                except Exception as e:
                    print "get_TVD EXC:", e

            except Exception as e:
                print "Nu pot comunica cu OBCA:", e

            sleep(self.TVD['PollInterval'])

    def print_time(self):
        if not self.TVD['Validate']:
            return

        if self.display_lock.acquire(False):
            now = datetime.now()
            data = str(now.day).zfill(2) + '/' + str(now.month).zfill(2) + '/' + str(now.year)
            ora = str(now.hour).zfill(2) + ':' + str(now.minute).zfill(2)
            self.lcd.clear()
            self.lcd.message("   " + data + '\n')
            self.lcd.message("     " + ora)
            self.display_lock.release()
        else:
            pass

    def print_time_thread(self):
        while True:
            self.print_time()
            sleep(30)

    def print_ip(self):
        output = ''
        while '192.168' not in output:
            p = Popen(self.ip_cmd, shell=True, stdout=PIPE)
            output = p.communicate()[0]
            time.sleep(1)
        self.lcd.clear()
        self.lcd.message(output.center(16))
        sleep(1)

    def print_version(self):
        self.lcd.clear()
        self.lcd.message("VERSION".center(16) + '\n' + self.get_version().center(16))
        sleep(1)

    def turn_led(self, value):
        if value == self.LED_GREEN:
            GPIO.output(self.LED_GREEN, GPIO.HIGH)
            GPIO.output(self.LED_RED, GPIO.LOW)
        elif value == self.LED_RED:
            GPIO.output(self.LED_GREEN, GPIO.LOW)
            GPIO.output(self.LED_RED, GPIO.HIGH)
        else:
            GPIO.output(self.LED_GREEN, GPIO.LOW)
            GPIO.output(self.LED_RED, GPIO.LOW)

    def validate_ticket(self):
        # print "#ticket: ", threading.current_thread().ident
        print time.time(), "Bilet: detectat"
        self.display_lock.acquire(True)
        self.lcd.clear()
        self.lcd.message("Validare in curs")
        if self.read_lock.acquire(False):
            try:
                self.turn_led(self.LED_GREEN)
                now = datetime.now()

                line_str = self.TVD['BusLine']

                if not self.TVD['Direction']:
                    line_str += 'R'

                time_str = str(now.hour).zfill(2) + ':' + str(now.minute).zfill(2)
                date_str = str(now.day).zfill(2) + '/' + str(now.month).zfill(2) + '/' + str(now.year)[-2:]

                # TODO Re-check CTS, is ticket inserted?
                self.prn.write('\n')
                self.prn.write('\n')
                self.prn.write('  ' + time_str + ' ' + line_str + '\n')
                self.prn.write('  ' + date_str + '\n')
                self.prn.write('  ' + self.TVD['BusId'][2:] + '\n')
                self.prn.write('\n')
                self.prn.flush()

                # TODO Add check to see if printing has ended
                sleep(0.7)
                GPIO.output(self.BACKFEED, GPIO.LOW)
                sleep(0.7)
                GPIO.output(self.BACKFEED, GPIO.HIGH)

                transaction = {
                    'timestamp': int(time.time()),
                    'route': self.TVD['BusLine'],
                    'schedule': self.TVD['GraphicId'],
                    'title_type': 1,
                    'subscription_id': None,
                    'value': 2.5,
                }
                self.transactions.append(transaction)

                while self.prn.getCTS():
                    # TODO add LCD message to remove locked ticket
                    # TODO Set a time-out and put TV in ERROR condition
                    sleep(0.1)
                    continue

                self.lcd.clear()
                self.lcd.message(" Tichet validat")
                self.buzzer_beep()
                sleep(1)
                self.display_lock.release()
                print time.time(), "Bilet: validat"

                # TODO Add new ticket transaction in local storage

                self.turn_led(self.LED_OFF)
                self.print_time()
                print time.time(), "Bilet: iesire"
            except Exception as e:
                self.display_lock.release()
                print time.time(), "Bilet: Eroare:", e
                # traceback.print_exc()
            finally:
                self.read_lock.release()
        else:
            self.display_lock.release()
            print "door #ticket locked"

    def buzzer_beep(self):
        # print "Beeeeeeeeeeeep"
        for i in range(1, 10):
            GPIO.output(self.BUZZER, GPIO.HIGH)
            sleep(0.003)
            GPIO.output(self.BUZZER, GPIO.LOW)
            sleep(0.003)

    def display_check_card(self):
        self.display_lock.acquire(True)
        self.lcd.clear()
        self.lcd.message("CONSULTARE  CARD\n")
        self.lcd.message("APROPIATI CARDUL")
        self.display_lock.release()

    def run(self):
        print "run: enter"

        while True:
            if self.TVD['Validate']:
                try:
                    # Validare bilete
                    if self.prn.getCTS():
                        self.validate_ticket()

                    # Validare carduri
                    if self.check_card_presence() and not self.button_pressed:
                        # print "card in loop"
                        self.validate_card()

                    if self.button_pressed == 2:
                        self.validate_second()
                        self.button_pressed = False

                    if self.button_pressed == 1:
                        self.validate_consult()
                        self.button_pressed = False

                    self.turn_led(self.LED_OFF)

                    sleep(0.4)
                except Exception as e:
                    print "run: EXC:", e
                    # traceback.print_exc()
            else:
                self.display_check_card()

                while not self.TVD['Validate']:
                    if self.check_card_presence():
                        self.validate_consult()
                        self.display_check_card()
                    sleep(0.4)

    def check_card_presence(self):
        (status, TagType) = self.MIFAREReader.MFRC522_Request(self.MIFAREReader.PICC_REQIDL)
        return status == self.MIFAREReader.MI_OK

    def button1_pressed(self):
        print "#1: ", threading.current_thread().ident
        if self.button_pressed:
            return
        else:
            self.button_pressed = 1

    def button2_pressed(self):
        print "button2_pressed: ident", threading.current_thread().ident
        if self.button_pressed:
            return
        else:
            self.button_pressed = 2

    def validate_consult(self):
        self.display_lock.acquire(True)
        if self.read_lock.acquire(False):
            try:
                print "validate_consult: start"
                self.lcd.clear()
                self.lcd.message("CONSULTARE  CARD\n")
                self.lcd.message("APROPIATI CARDUL")

                reading = True
                time_end = time.time() + 5
                while time.time() < time_end and reading:
                    if self.check_card_presence():
                        reading = False
                        self.display_lock.release()
                        print "validate_consult: Card detectat"
                        self.read_lock.release()
                        self.validate_card(consult=True)

                    sleep(0.2)
                print "validate_consult: Iesire buton 1"
            except Exception as e:
                print "validate_consult: Eroare:", e
                # traceback.print_exc()
            finally:
                try:
                    self.display_lock.release()
                except Exception as e:
                    pass
                try:
                    self.read_lock.release()
                except Exception as e:
                    pass
                self.button_pressed = False
        else:
            print "validate_consult: door locked"
            self.button_pressed = False
        self.print_time()

    def validate_second(self):
        self.display_lock.acquire(True)
        if self.read_lock.acquire(False):
            try:
                print "button2_pressed: start"
                self.lcd.clear()
                self.lcd.message(" Doua persoane\n")
                self.lcd.message("Apropiati cardul")

                reading = True
                time_end = time.time() + 5
                while time.time() < time_end and reading:
                    if self.check_card_presence():
                        reading = False
                        self.display_lock.release()
                        print "button2_pressed: Card detectat"
                        self.read_lock.release()
                        self.validate_card(second=True)

                    sleep(0.2)
                print "button2_pressed: Iesire buton 2"
            except Exception as e:
                print "button2_pressed: Eroare:", e
                # traceback.print_exc()
            finally:
                try:
                    self.display_lock.release()
                except Exception as e:
                    pass
                try:
                    self.read_lock.release()
                except Exception as e:
                    pass
                self.button_pressed = False
        else:
            print "button2_pressed: door locked"
            self.button_pressed = False
        self.print_time()

    def button1_pressed_handler(self, channel):
        threading.Thread(target=self.button1_pressed).start()

    def button2_pressed_handler(self, channel):
        threading.Thread(target=self.button2_pressed).start()

    def __exit__(self, exc_type, exc_val, exc_tb):
        GPIO.cleanup()
        print exc_type, exc_val, exc_tb



