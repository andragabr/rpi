#!/usr/bin/env bash

export MODULE_BASE="/home/pi/busticket/Validator_Valcea/validator/openfleetcardtool/"
export CLASS_PATH=${MODULE_BASE}:${MODULE_BASE}"OpenFleetCard.jar":${MODULE_BASE}"lib/gson-2.6.2.jar"

echo ${MODULE_BASE}
echo ${CLASS_PATH}

nice --20 java -cp ${CLASS_PATH} com.opendevlabs.openfleet.cardtool.OpenFleetCard -server
